library(testthat)
library(rgdax)

test_check("rgdax")
